let latest = null;
async function scan(){
 const url=document.getElementById('url').value.trim();
 const authorized=document.getElementById('authorized').checked;
 const err=document.getElementById('error'), loading=document.getElementById('loading'), results=document.getElementById('results'), btn=document.getElementById('scanBtn');
 err.classList.add('hidden');results.classList.add('hidden');
 if(!url){showError('Enter a website URL first.');return}
 if(!authorized){showError('Please confirm that you own the website or have explicit permission to test it.');return}
 loading.classList.remove('hidden');btn.disabled=true;btn.textContent='SCANNING…';
 try{
  const res=await fetch('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url,authorized})});
  const data=await res.json();if(!res.ok)throw new Error(data.error||'Scan failed.');
  latest=data;render(data);results.classList.remove('hidden');
 }catch(e){showError(e.message)}finally{loading.classList.add('hidden');btn.disabled=false;btn.innerHTML='RUN SCAN <span>↗</span>'}
}
function showError(msg){const e=document.getElementById('error');e.textContent=msg;e.classList.remove('hidden')}
function render(d){
 document.getElementById('meta').textContent=`${d.final_url}  ·  HTTP ${d.status}  ·  ${d.elapsed}s`;
 const m=d.summary;document.getElementById('metrics').innerHTML=[
 ['HIGH',m.high],['MEDIUM',m.medium],['LOW',m.low],['PASS',m.pass],['INFO',m.info]
 ].map(([k,v])=>`<div class="metric ${k.toLowerCase()}"><strong>${v}</strong><span>${k}</span></div>`).join('');
 document.getElementById('count').textContent=`${d.findings.length} CHECKS`;
 document.getElementById('findings').innerHTML=d.findings.map(f=>`<article class="finding"><span class="sev ${f.severity}">${f.severity}</span><div><h4>${esc(f.title)}</h4><p>${esc(f.detail)}</p><small>↳ ${esc(f.fix)}</small></div></article>`).join('');
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function exportReport(){
 if(!latest)return;
 const r=await fetch('/api/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({findings:latest.findings})});
 const blob=await r.blob(),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='webshield-report.csv';a.click();URL.revokeObjectURL(a.href);
}
document.getElementById('url').addEventListener('keydown',e=>{if(e.key==='Enter')scan()});
