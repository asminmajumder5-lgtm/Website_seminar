import csv, io, ipaddress, socket, ssl, time
from urllib.parse import urlparse, urlunparse
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import URLError, HTTPError
from flask import Flask, render_template, request, jsonify, make_response

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024
LAST_SCAN = {}

def validate_public_host(host):
    try:
        infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise ValueError("The hostname could not be resolved.")
    ips = {item[4][0] for item in infos}
    if not ips:
        raise ValueError("No IP address was found.")
    for ip in ips:
        addr = ipaddress.ip_address(ip.split("%")[0])
        if not addr.is_global:
            raise ValueError("For safety, private, local, and reserved network addresses cannot be scanned.")
    return ips

class SafeRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        p = urlparse(newurl)
        if p.scheme not in ("http", "https") or not p.hostname:
            raise ValueError("Redirect blocked: unsupported destination.")
        validate_public_host(p.hostname)
        return super().redirect_request(req, fp, code, msg, headers, newurl)

def scan_site(raw_url):
    raw_url = raw_url.strip()
    if len(raw_url) > 2048:
        raise ValueError("URL is too long.")
    if "://" not in raw_url:
        raw_url = "https://" + raw_url
    p = urlparse(raw_url)
    if p.scheme not in ("http", "https") or not p.hostname or p.username or p.password:
        raise ValueError("Enter a valid public http:// or https:// URL.")
    if p.port and not (1 <= p.port <= 65535):
        raise ValueError("Invalid port.")
    validate_public_host(p.hostname)

    clean = urlunparse((p.scheme, p.netloc, p.path or "/", p.params, p.query, ""))
    req = Request(clean, headers={"User-Agent": "WebShield-Seminar-Scanner/1.0", "Accept": "text/html,*/*;q=0.8"})
    opener = build_opener(SafeRedirect())
    start = time.time()
    try:
        with opener.open(req, timeout=8) as response:
            status = response.status
            headers = {k.lower(): v for k, v in response.headers.items()}
            body = response.read(256 * 1024)
            final_url = response.geturl()
    except HTTPError as e:
        status = e.code
        headers = {k.lower(): v for k, v in e.headers.items()}
        body = e.read(256 * 1024)
        final_url = e.geturl()
    except (URLError, TimeoutError, ssl.SSLError, OSError) as e:
        raise ValueError("Could not connect safely to that website. Check the URL and try again.") from e

    # Re-check the final destination after redirects.
    final_host = urlparse(final_url).hostname
    if not final_host:
        raise ValueError("The final destination was invalid.")
    validate_public_host(final_host)

    findings = []
    def add(sev, title, detail, fix):
        findings.append({"severity": sev, "title": title, "detail": detail, "fix": fix})

    if p.scheme != "https":
        add("HIGH", "Website uses HTTP", "The submitted URL did not use HTTPS, so transport encryption is not established.", "Enable HTTPS and redirect all HTTP traffic to HTTPS.")
    else:
        add("PASS", "HTTPS is used", "The submitted URL uses HTTPS.", "Keep TLS enabled and renew certificates before expiry.")

    checks = [
        ("content-security-policy", "MEDIUM", "Content-Security-Policy", "A Content Security Policy was not observed in the response.", "Define a restrictive CSP and test it in report-only mode before enforcement."),
        ("x-content-type-options", "LOW", "X-Content-Type-Options", "The response did not include this browser hardening header.", "Set X-Content-Type-Options: nosniff."),
        ("x-frame-options", "MEDIUM", "X-Frame-Options", "The response did not include this legacy clickjacking protection header.", "Set X-Frame-Options: DENY or SAMEORIGIN, or use CSP frame-ancestors."),
        ("referrer-policy", "LOW", "Referrer-Policy", "The response did not specify a Referrer-Policy.", "Set a policy such as strict-origin-when-cross-origin."),
        ("permissions-policy", "LOW", "Permissions-Policy", "The response did not specify a Permissions-Policy.", "Disable browser features that the application does not need.")
    ]
    for key, sev, title, detail, fix in checks:
        if key in headers:
            add("PASS", title + " present", "The response included " + title + ".", "Review the policy value to ensure it matches the application's needs.")
        else:
            add(sev, "Missing " + title, detail, fix)

    cookies = []
    for k, v in headers.items():
        if k == "set-cookie":
            cookies.append(v)
    if cookies:
        joined = " ".join(cookies).lower()
        missing = []
        if "httponly" not in joined: missing.append("HttpOnly")
        if "secure" not in joined: missing.append("Secure")
        if "samesite" not in joined: missing.append("SameSite")
        if missing:
            add("MEDIUM", "Cookie attributes need review", "At least one Set-Cookie header may be missing: " + ", ".join(missing) + ".", "Set HttpOnly, Secure (on HTTPS), and an appropriate SameSite value where applicable.")
        else:
            add("PASS", "Cookie attributes observed", "The inspected Set-Cookie response included common security attributes.", "Confirm each cookie is configured appropriately for its purpose.")
    else:
        add("INFO", "No cookies observed", "This response did not set a cookie during this request.", "No action required unless the application uses cookies on other routes.")

    if "server" in headers:
        add("INFO", "Server banner disclosed", "The response exposes a Server header: " + headers["server"][:120], "Consider minimizing unnecessary version or platform details.")
    else:
        add("PASS", "No Server banner observed", "No Server response header was observed.", "Continue minimizing unnecessary information disclosure.")

    return {
        "url": clean, "final_url": final_url, "status": status,
        "elapsed": round(time.time() - start, 2),
        "findings": findings,
        "summary": {
            "high": sum(x["severity"] == "HIGH" for x in findings),
            "medium": sum(x["severity"] == "MEDIUM" for x in findings),
            "low": sum(x["severity"] == "LOW" for x in findings),
            "pass": sum(x["severity"] == "PASS" for x in findings),
            "info": sum(x["severity"] == "INFO" for x in findings)
        }
    }

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/scan")
def api_scan():
    data = request.get_json(silent=True) or {}
    if data.get("authorized") is not True:
        return jsonify(error="Please confirm that you own the website or have explicit permission to test it."), 400
    url = str(data.get("url", ""))
    host = urlparse(url if "://" in url else "https://" + url).hostname or "unknown"
    now = time.time()
    if now - LAST_SCAN.get(host, 0) < 20:
        return jsonify(error="Please wait 20 seconds before scanning this host again."), 429
    try:
        result = scan_site(url)
        LAST_SCAN[host] = now
        return jsonify(result)
    except ValueError as e:
        return jsonify(error=str(e)), 400

@app.post("/api/export")
def export_csv():
    data = request.get_json(silent=True) or {}
    findings = data.get("findings", [])
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Severity", "Finding", "Observation", "Recommendation"])
    for item in findings[:40]:
        writer.writerow([item.get("severity",""), item.get("title",""), item.get("detail",""), item.get("fix","")])
    response = make_response(output.getvalue())
    response.headers["Content-Type"] = "text/csv"
    response.headers["Content-Disposition"] = "attachment; filename=webshield-report.csv"
    return response

@app.get("/health")
def health():
    return {"status": "ok", "app": "WebShield"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
