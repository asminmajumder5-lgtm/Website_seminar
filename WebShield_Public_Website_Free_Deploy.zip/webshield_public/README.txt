WEBSHIELD — PUBLIC DEPLOYMENT PACKAGE

WHAT IT DOES
- Real public web app when deployed (not localhost-only).
- Performs one safe HTTP GET request to the submitted public website.
- Checks HTTPS usage, common security response headers, observed cookie flags, and Server banner.
- Exports findings as CSV.
- Blocks localhost/private/reserved IP destinations and validates redirects.
- Requires an authorization checkbox and applies a simple per-host cooldown.

IMPORTANT LIMITATIONS
This is a seminar prototype, not a penetration-testing product. It does not exploit vulnerabilities, test authentication, crawl pages, submit forms, or prove exploitability. Findings are configuration indicators from one response and require manual verification. Only test sites you own or are explicitly authorized to assess.
The free Render service sleeps after 15 minutes without traffic and may take about a minute to wake. It has limited compute. No database is needed.

DEPLOY FOR FREE (RENDER)
1. Create/sign in to GitHub and create a new PUBLIC repository named webshield-seminar.
2. Extract this ZIP. Upload app.py, requirements.txt, render.yaml, templates/ and static/ to the repository root.
3. Go to https://render.com and sign in using GitHub.
4. Choose New + -> Blueprint, connect the repository, and follow the detected render.yaml configuration.
   OR choose New + -> Web Service and set:
   Build command: pip install -r requirements.txt
   Start command: gunicorn app:app
   Instance type: Free
5. Wait for deployment. Render will provide an https://....onrender.com URL.
6. Open that URL and test the scanner on a website you own or have permission to test.

LOCAL TEST (OPTIONAL)
Windows:
  py -m venv .venv
  .venv\Scripts\activate
  pip install -r requirements.txt
  py app.py
Then open http://127.0.0.1:5000

NOTE
A public repository makes source code visible. Do not add passwords, API keys, or personal secrets. This project has no secrets.
